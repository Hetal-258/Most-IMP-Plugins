<?php

namespace WPMailSMTP\Vendor\GuzzleHttp\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements \WPMailSMTP\Vendor\GuzzleHttp\Exception\GuzzleException
{
}
