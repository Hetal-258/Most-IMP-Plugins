<?php

namespace WPMailSMTP\Vendor\GuzzleHttp\Promise;

/**
 * Exception that is set as the reason for a promise that has been cancelled.
 */
class CancellationException extends \WPMailSMTP\Vendor\GuzzleHttp\Promise\RejectionException
{
}
